import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Animated,
  Easing,
  Button,
  TouchableOpacity,
  Text,
} from 'react-native';

import Feather from 'react-native-vector-icons/Feather';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Login from './components/Login';
import Registro from './components/Register';
import Menu from './components/Menu';
import Chamas from './components/Chamas';
import Diamante from './components/Diamante';
import Fantasmatico from './components/Fantasmatico';
import Quatro from './components/Quatro';
import Omnitrix from './components/Omnitrix';

const Navegacao = createStackNavigator();
export default class App extends React.Component {
  render() {
    return (
      <NavigationContainer>
        <Navegacao.Navigator
          screenOptions={{
            tabBarActiveTintColor: 'tomato',
            tabBarInactiveTintColor: 'gray',
          }}>
          <Navegacao.Screen
            name="Omnitrix"
            component={Omnitrix}
            options={{
              headerShown: false,
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
            }}
          />
          <Navegacao.Screen
            name="Login"
            component={Login}
            options={{
              headerShown: true,
              headerStyle: {
                backgroundColor: '#191919',
              },
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <Navegacao.Screen
            name="Registro"
            component={Registro}
            options={{
              headerShown: true,
              headerStyle: {
                backgroundColor: '#191919',
              },
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />

          <Navegacao.Screen
            name="Menu"
            component={Menu}
            options={{
              headerShown: false,
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
            }}
          />

          <Navegacao.Screen
            name="Chamas"
            component={Chamas}
            options={{
              headerShown: true,
              headerStyle: {
                backgroundColor: '#191919',
              },
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />

          <Navegacao.Screen
            name="Diamante"
            component={Diamante}
            options={{
              headerShown: true,
              headerStyle: {
                backgroundColor: '#191919',
              },
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />

          <Navegacao.Screen
            name="Fantasmático"
            component={Fantasmatico}
            options={{
              headerShown: true,
              headerStyle: {
                backgroundColor: '#191919',
              },
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />

          <Navegacao.Screen
            name="Quatro-Braços"
            component={Quatro}
            options={{
              headerShown: true,
              headerStyle: {
                backgroundColor: '#191919',
              },
              tabBarIcon: ({ color }) => {
                <Feather name="user" size={20} color={color} />;
              },
              headerTintColor: '#fff',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
        </Navegacao.Navigator>
      </NavigationContainer>
    );
  }
}

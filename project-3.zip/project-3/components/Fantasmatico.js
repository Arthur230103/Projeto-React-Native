import React, { useState, useEffect } from 'react';
import {
  View,
  KeyboardAvoidingView,
  Image,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';
import Constants from 'expo-constants';
import AssetExample from '../components/AssetExample';
import { Card } from 'react-native-paper';
import Button from './button';

import { useNavigation } from '@react-navigation/native';

export default function Fantasmatico() {
  const { navigate } = useNavigation();

  return (
    <View style={styles.background}>
      <View>
        <Image
          source={require('../assets/Fantasmatico.png')}
          style={styles.imageFantasmatico}
        />
      </View>
      <Text style={styles.txtFantasmatico}>
        Fantasmático é semelhante a um fantasma branco, com linhas pretas
        passando por seu corpo e seu olho é roxo. O Omnitrix localiza-se dentro
        de uma das linhas em seu peito. Sua cauda lembra bastante uma fumaça,
        sendo confirmado que inicialmente ele era para ser baseado em um gênio
        da lâmpada.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#191919',
  },
  imageFantasmatico: {
    top: -50,
    bottom: 250,
    width: 300,
    height: 300,
    borderRadius: 300 / 2,
  },
  txtFantasmatico: {
    fontSize: 20,
    fontFamily: 'Calibri',
    color: '#FFF',
  }
});

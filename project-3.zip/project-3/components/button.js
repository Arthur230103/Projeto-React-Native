import React from 'react';
import { Text, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { StyleSheet } from 'react-native';

class Button extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <TouchableOpacity
        onPress={() => this.props.onPress()}
        style={stylesButton.container}>
        <Text style={stylesButton.btnSubmit}>{this.props.text}</Text>
      </TouchableOpacity>
    );
  }
}

export default Button;

const stylesButton = StyleSheet.create({
  container: {
    marginTop: 10,
  },
  btnSubmit: {
    marginTop: 10,
    color: '#FFF',
  },
});

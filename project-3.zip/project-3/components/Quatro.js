import React, { useState, useEffect } from 'react';
import {
  View,
  KeyboardAvoidingView,
  Image,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';
import Constants from 'expo-constants';
import AssetExample from '../components/AssetExample';
import { Card } from 'react-native-paper';
import Button from './button';

import { useNavigation } from '@react-navigation/native';

export default function Quatro() {
  const { navigate } = useNavigation();

  return (
    <View style={styles.background}>
      <View>
        <Image
          source={require('../assets/Quatro.png')}
          style={styles.imageQuatro}
        />
      </View>
      <Text style={styles.txtQuatro}>
        Quatro Braços é um alienígena humanoide que é de aproximadamente 3,60
        metros de altura, tem músculos avantajados, dois pares de braços de
        quatro dedos e pele vermelha bem desenvolvida. A listra preta vai desde
        o queixo até o lábio inferior, e ele tem quatro olhos: um par principal
        e um par menor abaixo deles. Na série original, Quatro Braços veste uma
        traje branco com uma linha preta seguindo para baixo, calças pretas e
        luvas sem dedos. Ele usa o símbolo do Omnitrix no ombro esquerdo
        superior. Seus olhos são amarelos e ele não tem cabelo.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#191919',
  },
  imageQuatro: {
    top: -20,
    bottom: 250,
    width: 300,
    height: 300,
    borderRadius: 300 / 2,
  },
  txtQuatro: {
    fontSize: 20,
    fontFamily: 'Calibri',
    color: '#FFF',
  }
});

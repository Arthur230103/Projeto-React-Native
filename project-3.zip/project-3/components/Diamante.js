import React, { useState, useEffect } from 'react';
import {
  View,
  KeyboardAvoidingView,
  Image,
  TextInput,
  TouchableOpacity,
  Text,
  ScrollView,
  StyleSheet,
  Animated,
} from 'react-native';
import Constants from 'expo-constants';
import AssetExample from '../components/AssetExample';
import { Card } from 'react-native-paper';
import Button from './button';

import { useNavigation } from '@react-navigation/native';

export default function Diamante() {
  const { navigate } = useNavigation();
  return (
    <ScrollView style={styles.background}>
      <View>
        <Image
          source={require('../assets/Diamante.png')}
          style={styles.imageDiamante}
        />
      </View>
      <View>
        <Text style={styles.txtDiamante}>
          O corpo de Diamante é composto por um cristal orgânico extremamente
          resistente, que se assemelham a tadenita, tornando-o quase
          invulnerável. Também possui quatro cristais grandes em suas costas.
          Seu corpo é completamente verde cristalizado. O corpo todo é coberto
          por uma roupa preta e branca. O Omnitrix está em seu peito esquerdo.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  background: {
    display: 'flex',
    height:"100%",
    alignItems: 'center',
    //justifyContent: 'center',
    backgroundColor: '#191919',
  },
  imageDiamante: {
    top: 0,
    bottom: 250,
    width: 300,
    height: 300,
    borderRadius: 300 / 2,
    alignSelf: 'center'
  },
  txtDiamante: {
    fontSize: 40,
    fontFamily: 'Calibri',
    color: '#FFF',
  },
});

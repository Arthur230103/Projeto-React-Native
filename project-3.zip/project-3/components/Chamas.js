import React, { useState, useEffect } from 'react';
import {
  View,
  KeyboardAvoidingView,
  Image,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';
import Constants from 'expo-constants';
import AssetExample from '../components/AssetExample';
import { Card } from 'react-native-paper';
import Button from './button';

import { useNavigation } from '@react-navigation/native';

export default function Chamas() {
  const { navigate } = useNavigation();

  return (
    <View style={styles.background}>
      <View>
        <Image
          source={require('../assets/Chamas.png')}
          style={styles.imageChamas}
        />
      </View>
      <View>
        <Text style={styles.txtChamas}>
          Chama é uma forma de vida humanoide baseada principalmente em magma.
          Seu corpo é constituído por um interior de magma brilhante coberta por
          um vermelho escuro. Seu corpo irradia grandes quantidades de calor.
          Seus pés têm apenas dois dedos e uma parte traseira pontuda. Chama
          usava o símbolo do Omnitrix no peito.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#191919',
  },
  imageChamas: {
    top: -50,
    bottom: 250,
    width: 300,
    height: 300,
    borderRadius: 300 / 2,
  },
  txtChamas: {
    fontSize: 20,
    fontFamily: 'Calibri',
    color: '#FFF',
  },
});

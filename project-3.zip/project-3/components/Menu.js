import React, { useState, useEffect } from 'react';
import {
  View,
  KeyboardAvoidingView,
  Image,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Animated,
} from 'react-native';
import Constants from 'expo-constants';
import AssetExample from '../components/AssetExample';
import { Card } from 'react-native-paper';
import Button from './button';

import { useNavigation } from '@react-navigation/native';

export default function Menu() {
  const { navigate } = useNavigation();

  return (
    <View style={styles.background}>
      <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity={0.5}
        onPress={() => navigate('Chamas')}>
        <Image
          source={require('../assets/Chamas.png')}
          style={styles.btnImageChamas}
        />
        <View style={styles.buttonIconSeparatorStyle} />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity={0.5}
        onPress={() => navigate('Diamante')}>
        <Image
          source={require('../assets/Diamante.png')}
          style={styles.btnImageDiamante}
        />
        <View style={styles.buttonIconSeparatorStyle} />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity={0.5}
        onPress={() => navigate('Fantasmático')}>
        <Image
          source={require('../assets/Fantasmatico.png')}
          style={styles.btnImageFantasmatico}
        />
        <View style={styles.buttonIconSeparatorStyle} />
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.buttonStyle}
        activeOpacity={0.5}
        onPress={() => navigate('Quatro-Braços')}>
        <Image
          source={require('../assets/Quatro.png')}
          style={styles.btnImageQuatro}
        />
        <View style={styles.buttonIconSeparatorStyle} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#191919',
  },
  btnImageChamas: {
    marginBottom: 20,
    width: 150,
    height: 150,
    borderRadius: 150 / 2,
  },
  btnImageDiamante: {
    marginBottom: 20,
    width: 150,
    height: 150,
    borderRadius: 150 / 2,
  },
  btnImageFantasmatico: {
    marginBottom: 20,
    width: 150,
    height: 150,
    borderRadius: 150 / 2,
  },
  btnImageQuatro: {
    width: 150,
    height: 150,
    borderRadius: 150 / 2,
  },
});
